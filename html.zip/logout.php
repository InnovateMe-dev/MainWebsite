<?php
session_start();
session_destroy();
?>
<html>
<body>
Logout Successful
</body>
</html>